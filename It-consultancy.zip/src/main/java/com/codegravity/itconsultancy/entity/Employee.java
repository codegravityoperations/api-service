package com.codegravity.itconsultancy.entity;

public class Employee {
}
