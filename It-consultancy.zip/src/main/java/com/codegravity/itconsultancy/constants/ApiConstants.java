package com.codegravity.itconsultancy.constants;

/**
 * All REST API endpoint paths as constants.
 *
 * Why? If you change "/api/employees" to "/api/v1/employees",
 * you change it HERE once — not in 10 different controller methods.
 *
 * Pattern: BASE → RESOURCE → ACTION
 */
public final class ApiConstants {

    private ApiConstants() {
        throw new UnsupportedOperationException("Constants class cannot be instantiated");
    }

    // ─── Base ────────────────────────────────────────────────────
    public static final String API_BASE = "/api";

    // ─── Auth ────────────────────────────────────────────────────
    public static final String AUTH_BASE         = API_BASE + "/auth";
    public static final String AUTH_LOGIN        = AUTH_BASE + "/login";
    public static final String AUTH_REFRESH      = AUTH_BASE + "/refresh";
    public static final String AUTH_LOGOUT       = AUTH_BASE + "/logout";

    // ─── Employee ────────────────────────────────────────────────
    public static final String EMPLOYEE_BASE     = API_BASE + "/employees";
    public static final String EMPLOYEE_REGISTER = EMPLOYEE_BASE + "/register";
    public static final String EMPLOYEE_BY_ID    = EMPLOYEE_BASE + "/{id}";

    // ─── Candidate ───────────────────────────────────────────────
    public static final String CANDIDATE_BASE     = API_BASE + "/candidates";
    public static final String CANDIDATE_REGISTER = CANDIDATE_BASE + "/register";
    public static final String CANDIDATE_BY_ID    = CANDIDATE_BASE + "/{id}";

    // ─── Public endpoints (no JWT required) ──────────────────────
    // Used in SecurityConfig to whitelist these from authentication
    public static final String[] PUBLIC_ENDPOINTS = {
            AUTH_LOGIN,
            AUTH_REFRESH,
            EMPLOYEE_REGISTER,
            CANDIDATE_REGISTER,
            "/swagger-ui/**",
            "/swagger-ui.html",
            "/api-docs/**",
            "/actuator/health"
    };
}